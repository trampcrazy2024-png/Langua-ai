import React, { useState, useEffect, useRef } from "react";
import { Compass, Sparkles } from "lucide-react";
import { PHRASES } from "./data";
import { Phrase } from "./types";
import { getSpeechSynthesis, newUtterance } from "./lib/speech";
import { apiUrl } from "./lib/config";

// Import custom modular components
import MatrixTab from "./components/MatrixTab";
import TranslatorTab from "./components/translator/TranslatorTab";
import OcrTab from "./components/OcrTab";
import PodcastTab from "./components/PodcastTab";
import SafetyTab from "./components/SafetyTab";
import QuizTab from "./components/QuizTab";
import ChatTab from "./components/ChatTab";
import PlannerTab from "./components/PlannerTab";
import WelcomeScreen from "./components/WelcomeScreen";
import DialectCompareTab from "./components/DialectCompareTab";
import ScenarioTab from "./components/ScenarioTab";
import { TabErrorBoundary } from "./components/TabErrorBoundary";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("AI Chat");
  const [showWelcome, setShowWelcome] = useState<boolean>(() => {
    try {
      return localStorage.getItem("travelapp_seen_welcome") !== "true";
    } catch {
      return true;
    }
  });
  const [favorites, setFavorites] = useState<string[]>([]);
  const [customPhrases, setCustomPhrases] = useState<Phrase[]>([]);
  const [speechSpeed, setSpeechSpeed] = useState<number>(0.9);
  const [offlineMode, setOfflineMode] = useState<boolean>(() => {
    try { return !navigator.onLine; } catch { return false; }
  });
  const [autoDetectedOffline, setAutoDetectedOffline] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [gatewayStatus, setGatewayStatus] = useState<string>("AI Gateway");

  // Real network detection: if the phone actually loses internet (e.g. no
  // signal in a foreign country), the app finds out immediately from the
  // browser's real 'online'/'offline' events — not just when the user
  // remembers to flip the manual toggle.
  useEffect(() => {
    const goOffline = () => {
      setOfflineMode(true);
      setAutoDetectedOffline(true);
      triggerToast("📡 اینترنت قطع شد — مکالمه اصلی با هوش مصنوعی محلی و دیکشنری همچنان کار می‌کنند (تا زمانی که گیت‌وی محلی در دسترس باشد)؛ فقط قابلیت‌های وابسته به سرویس بیرونی محدود می‌شوند.");
    };
    const goOnline = () => {
      if (autoDetectedOffline) {
        setOfflineMode(false);
        setAutoDetectedOffline(false);
        triggerToast("✅ اتصال اینترنت برقرار شد.");
      }
    };
    window.addEventListener("offline", goOffline);
    window.addEventListener("online", goOnline);
    return () => {
      window.removeEventListener("offline", goOffline);
      window.removeEventListener("online", goOnline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoDetectedOffline]);

  // The app talks to one local gateway. The gateway itself decides whether
  // a local Ollama model, DeepSeek, or another configured fallback provider
  // handles a request - see gateway/gateway.py.
  useEffect(() => {
    let cancelled = false;
    const checkGateway = async () => {
      try {
        const response = await fetch(apiUrl("/health"));
        if (!response.ok) throw new Error();
        const data = await response.json();
        if (cancelled) return;
        if (data.status === "ok") setGatewayStatus("AI Gateway · online");
        else setGatewayStatus("AI Gateway · offline");
      } catch {
        if (!cancelled) setGatewayStatus("AI Gateway · unavailable");
      }
    };
    checkGateway();
    const timer = window.setInterval(checkGateway, 15000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, []);

  // Load state from localStorage on init
  useEffect(() => {
    const savedFavs = localStorage.getItem("travelapp_favorites");
    if (savedFavs) {
      try {
        setFavorites(JSON.parse(savedFavs));
      } catch (e) {
        console.error("Failed to parse favorites", e);
      }
    }

    const savedCustom = localStorage.getItem("travelapp_custom_phrases");
    if (savedCustom) {
      try {
        setCustomPhrases(JSON.parse(savedCustom));
      } catch (e) {
        console.error("Failed to parse custom phrases", e);
      }
    }
  }, []);

  // Sync state to localStorage
  const saveFavorites = (newFavs: string[]) => {
    setFavorites(newFavs);
    localStorage.setItem("travelapp_favorites", JSON.stringify(newFavs));
  };

  const saveCustomPhrases = (newCustom: Phrase[]) => {
    setCustomPhrases(newCustom);
    localStorage.setItem("travelapp_custom_phrases", JSON.stringify(newCustom));
  };

  /*
   * Bug fix: this used to be `const toastTimer = { h: null as any };`
   * declared directly in the component body, which means it was a
   * brand-new object on every render - the "clear the previous
   * timer" check right below could never actually find a previous
   * timer, so rapid toasts would stack their auto-dismiss timeouts
   * instead of replacing them, and nothing cleared the pending
   * timeout on unmount either. useRef persists across renders and
   * we add a cleanup effect below.
   */
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const triggerToast = (msg: string) => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToast(msg);
    toastTimerRef.current = setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, []);

  // Toggle favorite
  const toggleFavorite = (id: string) => {
    if (favorites.includes(id)) {
      const updated = favorites.filter((f) => f !== id);
      saveFavorites(updated);
      triggerToast("⭐ از لیست علاقه‌مندی‌ها حذف شد.");
    } else {
      const updated = [...favorites, id];
      saveFavorites(updated);
      triggerToast("⭐ به لیست علاقه‌مندی‌ها الحاق شد.");
    }
  };

  // Delete custom phrase
  const deleteCustomPhrase = (id: string) => {
    const updated = customPhrases.filter((p) => p.id !== id);
    saveCustomPhrases(updated);
    triggerToast("🗑️ عبارت شخصی با موفقیت حذف شد.");
  };

  // Add custom phrase
  const addCustomPhrase = (newPhrase: Omit<Phrase, "id">) => {
    const pWithId: Phrase = {
      ...newPhrase,
      id: `custom_${Date.now()}`
    };
    const updated = [...customPhrases, pWithId];
    saveCustomPhrases(updated);
  };

  // Universal text speaker using HTML5 SpeechSynthesis.
  // langCode lets callers pass the exact dialect/language (e.g. from
  // getLangCode(phrase.dialect, phrase.lang)); when omitted we auto-detect
  // Arabic-script vs Latin-script text so English phrases no longer get
  // read with an Arabic voice.
  const playSpeech = (
    text: string,
    _id: string,
    langCode?: string,
    voiceOptions?: { pitch?: number; rate?: number; voiceHint?: string },
    onEnd?: () => void
  ) => {
    const tts = getSpeechSynthesis();
    if (!tts) { triggerToast("⚠️ سیستم پخش صوتی در این دستگاه در دسترس نیست"); onEnd?.(); return; }
    try { tts.cancel(); } catch {}
    const resolvedLang = langCode || (/[\u0600-\u06FF]/.test(text) ? "ar-SA" : "en-US");
    const utt = newUtterance(text);
    if (!utt) { triggerToast("⚠️ سازندهٔ گفتار در دسترس نیست"); onEnd?.(); return; }
    utt.lang = resolvedLang;
    utt.rate = speechSpeed * (voiceOptions?.rate ?? 1);
    if (voiceOptions?.pitch !== undefined) utt.pitch = voiceOptions.pitch;
    if (onEnd) {
      utt.onend = onEnd;
      utt.onerror = onEnd;
    }
    const voices = (tts.getVoices?.() ?? []) as any[];
    const exact = voices.find((v) => v.lang.toLowerCase() === resolvedLang.toLowerCase());
    const family = voices.find((v) => v.lang.toLowerCase().startsWith(resolvedLang.slice(0, 2).toLowerCase()));
    let chosen = exact || family;
    const voiceHint = voiceOptions?.voiceHint;
    if (voiceHint) {
      const hinted = voices.find((v) =>
        v.lang.toLowerCase().startsWith(resolvedLang.slice(0, 2).toLowerCase()) &&
        v.name.toLowerCase().includes(voiceHint.toLowerCase()));
      if (hinted) chosen = hinted;
    }
    if (chosen) utt.voice = chosen;
    else if (resolvedLang.startsWith("ar") && voices.length > 0)
      triggerToast("⚠️ صدای این لهجه نصب نیست؛ نزدیکترین صدای موجود پخش میشود.");
    tts.speak(utt);
    triggerToast("🔊 در حال تلفظ بومی...");
  };

  // Copy to clipboard helper
  const copyToClipboard = (text: string) => {
    try { navigator.clipboard?.writeText(text); triggerToast("📋 متن کپی شد."); }
    catch { triggerToast("⚠️ کلیپبورد در این مرور در دسترس نیست"); }
  };

  // Navigation tabs, reprioritized around the app's actual goal (speaking
  // practice + dialect learning), not flattened into one list: AI Chat
  // (Speaking Mode, Accent Coach, Language Memory, Model Manager all live
  // there), Scenario (guided conversation practice), and Compare
  // (pronunciation comparison across dialects) are the core loop and stay
  // one tap away. Everything else genuinely useful for a traveler but not
  // part of the speaking/pronunciation loop itself moves behind "بیشتر"
  // (More) instead of being deleted - nothing here is removed, just no
  // longer competing for the same row as the core loop.
  const CORE_TABS = ["AI Chat", "Scenario", "Compare"];
  const MORE_TABS = ["Translator", "Lingo Quiz", "Matrix", "Podcast", "Planner", "Sign OCR", "SOS Safety"];
  const [showMoreTabs, setShowMoreTabs] = useState(false);

  if (showWelcome) {
    const dismiss = (destination: string) => {
      try {
        localStorage.setItem("travelapp_seen_welcome", "true");
      } catch {}
      setActiveTab(destination);
      setShowWelcome(false);
    };
    return (
      <WelcomeScreen
        onStart={() => dismiss("AI Chat")}
        onBrowseLibrary={() => dismiss("Translator")}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#090D16] text-[#F8FAFC] flex flex-col font-sans transition-all selection:bg-[#14B8A6]/30 select-none pb-12">
      
      {/* 1. APP HEADER - ALIGNED PERFECTLY WITH ANDROID MAIN SCREEN */}
      <div className="bg-[#0C101F] border-b border-[#1E293B] py-3.5 px-4 flex justify-between items-center w-full sticky top-0 z-50 shadow-md">
        <div className="flex items-center gap-2.5">
          {/* Home icon block */}
          <div className="w-9 h-9 rounded-lg bg-[#14B8A6] flex items-center justify-center text-black shadow-inner">
            <Compass className="w-5 h-5 animate-spin-slow" />
          </div>
          <div className="text-left">
            <div className="flex items-center gap-1 font-bold">
              <span className="text-[#F8FAFC] text-base tracking-tight font-display">TravelApp</span>
              <span className="text-[#14B8A6] text-base font-display">66</span>
            </div>
            <p className="text-[#94A3B8] text-[10.5px]">Clean Architecture Solution</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {offlineMode && (
            <div className="bg-yellow-500/10 border border-yellow-500/30 text-yellow-500 text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1">
              <span>✈️ حالت پرواز آفلاین</span>
            </div>
          )}
          <div className="bg-[#14B8A6]/15 border border-[#14B8A6]/20 text-[#14B8A6] text-[9.5px] font-extrabold px-2.5 py-1 rounded">
            {gatewayStatus}
          </div>
        </div>
      </div>

      {/* 2. HORIZONTAL TAB ROW - core loop first, secondary tabs behind "بیشتر" */}
      <div className="bg-[#0C101F] border-b border-[#1E293B]/70 py-2 px-3 sticky top-[61px] z-40 overflow-x-auto scrollbar-none flex gap-2">
        {CORE_TABS.map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                triggerToast(`📁 ورود به بخش ${tab}`);
              }}
              className={`text-xs font-black px-4.5 py-2.5 rounded-xl transition-all duration-300 shrink-0 flex items-center gap-1.5 cursor-pointer ${
                isActive 
                  ? "bg-[#14B8A6] text-black shadow-lg" 
                  : "text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1E293B]/30"
              }`}
            >
              <span>{tab === "Compare" ? "🌍 Compare" :
                    tab === "AI Chat" ? "💬 AI Chat" :
                    "🎭 Scenario"}</span>
            </button>
          );
        })}
        <button
          onClick={() => setShowMoreTabs((v) => !v)}
          className={`text-xs font-black px-4.5 py-2.5 rounded-xl transition-all duration-300 shrink-0 flex items-center gap-1.5 cursor-pointer ${
            showMoreTabs || MORE_TABS.includes(activeTab)
              ? "bg-[#1E293B] text-[#F8FAFC]"
              : "text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1E293B]/30"
          }`}
        >
          <span>{showMoreTabs ? "▲ بستن" : "⋯ بیشتر"}</span>
        </button>
        {showMoreTabs && MORE_TABS.map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                setShowMoreTabs(false);
                triggerToast(`📁 ورود به بخش ${tab}`);
              }}
              className={`text-xs font-black px-4.5 py-2.5 rounded-xl transition-all duration-300 shrink-0 flex items-center gap-1.5 cursor-pointer ${
                isActive 
                  ? "bg-[#14B8A6] text-black shadow-lg" 
                  : "text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1E293B]/30"
              }`}
            >
              <span>{tab === "Matrix" ? "📊 Matrix" :
                    tab === "Translator" ? "🗣️ Translator" :
                    tab === "Planner" ? "🗺️ Planner" :
                    tab === "Sign OCR" ? "📷 Sign OCR" :
                    tab === "Podcast" ? "🎧 Podcast" :
                    tab === "SOS Safety" ? "🚨 SOS Safety" : "🎯 Lingo Quiz"}</span>
            </button>
          );
        })}
      </div>

      {/* 3. MAIN WORKSPACE */}
      <div className="w-full max-w-5xl mx-auto px-4 pt-5 flex-1">
        <TabErrorBoundary key={activeTab} label={activeTab}>
        {activeTab === "Matrix" && (
          <MatrixTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
            allPhrases={PHRASES}
            setActiveTab={setActiveTab}
            offlineMode={offlineMode}
            setOfflineMode={setOfflineMode}
          />
        )}

        {activeTab === "Translator" && (
          <TranslatorTab 
            phrases={PHRASES}
            customPhrases={customPhrases}
            favorites={favorites}
            toggleFavorite={toggleFavorite}
            deleteCustomPhrase={deleteCustomPhrase}
            addCustomPhrase={addCustomPhrase}
            playSpeech={playSpeech}
            triggerToast={triggerToast}
            copyToClipboard={copyToClipboard}
            speechSpeed={speechSpeed}
            setSpeechSpeed={setSpeechSpeed}
            offlineMode={offlineMode}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === "Compare" && (
          <DialectCompareTab playSpeech={playSpeech} triggerToast={triggerToast} />
        )}

        {activeTab === "AI Chat" && (
          <ChatTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
          />
        )}

        {activeTab === "Scenario" && (
          <ScenarioTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
            offlineMode={offlineMode}
          />
        )}

        {activeTab === "Planner" && (
          <PlannerTab 
            triggerToast={triggerToast}
            offlineMode={offlineMode}
          />
        )}

        {activeTab === "Sign OCR" && (
          <OcrTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
            offlineMode={offlineMode}
          />
        )}

        {activeTab === "Podcast" && (
          <PodcastTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
          />
        )}

        {activeTab === "SOS Safety" && (
          <SafetyTab 
            playSpeech={playSpeech}
            triggerToast={triggerToast}
          />
        )}

        {activeTab === "Lingo Quiz" && (
          <QuizTab 
            triggerToast={triggerToast}
            offlineMode={offlineMode}
          />
        )}
        </TabErrorBoundary>
      </div>

      {/* 4. TOAST NOTIFICATION FLOATER */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-[#14B8A6] text-[#090D16] text-[11px] font-black py-2.5 px-5 rounded-full shadow-[0_4px_15px_rgba(20,184,166,0.35)] flex items-center gap-2 z-50 animate-scaleUp text-right" dir="rtl">
          <Sparkles className="w-4 h-4 animate-pulse" />
          <span>{toast}</span>
        </div>
      )}

    </div>
  );
}
