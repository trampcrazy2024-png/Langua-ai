import { apiUrl } from "./config";

export async function apiFetch<T>(path: string, init?: any): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const secret = import.meta.env.VITE_TRAVELAPP_SHARED_SECRET || "";
  if (secret) headers["x-travelapp-secret"] = secret;
  const res = await fetch(apiUrl(path), {
    ...(init || {}),
    headers: { ...headers, ...((init && init.headers) || {}) },
    body: init && init.body ? JSON.stringify(init.body) : undefined,
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return (await res.json()) as T;
}
