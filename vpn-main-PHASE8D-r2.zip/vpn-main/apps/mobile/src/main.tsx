import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom/client';
import { APP_NAME, APP_VERSION } from '@lingua/shared';
import './styles.css';
import LocalAI from './services/localAI';
import {
  checkLocalAI,
  type LocalAIStatus
} from './services/localAIService';

interface ChatMessage {
  id: number;
  role: 'user' | 'assistant';
  text: string;
}

function App() {
  const [status, setStatus] = useState<LocalAIStatus | null>(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [modelLoading, setModelLoading] = useState(false);
  const [error, setError] = useState('');
  const [importedModel, setImportedModel] = useState<{
    path: string;
    name: string;
    size: number;
  } | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const nextId = useRef(1);

  useEffect(() => {
    void refreshStatus();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function refreshStatus() {
    const nextStatus = await checkLocalAI();
    setStatus(nextStatus);
  }

  async function importModel() {
    if (modelLoading || loading) {
      return;
    }

    setError('');
    setModelLoading(true);

    try {
      /*
       * This step ONLY imports/copies the GGUF file.
       * It intentionally does NOT call nativeLoadModel().
       */
      const selected = await LocalAI.pickModel();

      if (!selected.ok || !selected.path) {
        throw new Error('No model was selected.');
      }

      setImportedModel({
        path: selected.path,
        name: selected.name || selected.path.split('/').pop() || 'model.gguf',
        size: selected.size || 0
      });

      await refreshStatus();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to import the model.'
      );
    } finally {
      setModelLoading(false);
    }
  }

  async function loadImportedModel() {
    if (modelLoading || loading || !importedModel) {
      return;
    }

    setError('');
    setModelLoading(true);

    try {
      const loaded = await LocalAI.loadModel({
        path: importedModel.path
      });

      if (!loaded.ok || !loaded.loaded) {
        throw new Error('Failed to load the selected model.');
      }

      await refreshStatus();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to load the model.'
      );
    } finally {
      setModelLoading(false);
    }
  }

  async function unloadModel() {
    if (modelLoading || loading) {
      return;
    }

    setError('');
    setModelLoading(true);

    try {
      await LocalAI.unloadModel();
      await refreshStatus();
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to unload the model.'
      );
    } finally {
      setModelLoading(false);
    }
  }

  async function sendMessage() {
    const text = message.trim();

    if (!text || loading || !status?.modelLoaded) {
      return;
    }

    const userMsg: ChatMessage = {
      id: nextId.current++,
      role: 'user',
      text
    };

    const assistantId = nextId.current++;

    setMessages((prev) => [
      ...prev,
      userMsg,
      { id: assistantId, role: 'assistant', text: '' }
    ]);
    setMessage('');
    setLoading(true);
    setError('');

    /*
     * Phase 8-D: subscribe BEFORE calling streamChat() so no
     * early tokens are lost, and append each piece to the
     * in-progress assistant bubble as it arrives instead of
     * waiting for the whole reply.
     */
    const listener = await LocalAI.addListener(
      'generationToken',
      ({ token }) => {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId ? { ...m, text: m.text + token } : m
          )
        );
      }
    );

    try {
      const result = await LocalAI.streamChat({ message: text });

      const finalText = (result.value || '').trim();

      const isCancelled = result.status === 'cancelled';

      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantId
            ? {
                ...m,
                text:
                  finalText ||
                  (isCancelled
                    ? '(cancelled)'
                    : '(no output was generated)')
              }
            : m
        )
      );
    } catch (err) {
      setMessages((prev) => prev.filter((m) => m.id !== assistantId));

      setError(
        err instanceof Error
          ? err.message
          : 'Local AI request failed.'
      );
    } finally {
      await listener.remove();
      setLoading(false);
    }
  }

  async function cancelGeneration() {
    if (!loading) {
      return;
    }

    try {
      await LocalAI.cancelGeneration();
    } catch {
      /*
       * Best-effort - if this fails, streamChat() will still
       * eventually resolve or reject on its own.
       */
    }
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  }

  const isModelLoaded = status?.modelLoaded === true;

  return (
    <main className="app">
      <div className="assistant">
        <header className="header">
          <div>
            <h1>{APP_NAME}</h1>
            <p>Offline-first AI Assistant</p>
          </div>
          <span className="version">{APP_VERSION}</span>
        </header>

        <div className="ai-status">
          <span
            className={
              'status-dot' + (status?.available ? ' online' : '')
            }
          />

          {status === null && <span>Checking...</span>}

          {status !== null && (
            <span>
              {status.available ? `Ready — ${status.engine}` : 'Unavailable'}
              {' · '}
              {isModelLoaded
                ? status.modelPath
                  ? status.modelPath.split('/').pop()
                  : 'Model loaded'
                : 'No local model is loaded'}
            </span>
          )}
        </div>

        <div className="messages">
          {!isModelLoaded && (
            <div className="model-controls">
              <button
                type="button"
                onClick={() => void importModel()}
                disabled={modelLoading || loading || !status?.available}
              >
                {modelLoading ? 'Importing...' : 'Import GGUF Model'}
              </button>

              {importedModel && (
                <button
                  type="button"
                  onClick={() => void loadImportedModel()}
                  disabled={modelLoading || loading}
                >
                  {modelLoading ? 'Loading...' : `Load ${importedModel.name}`}
                </button>
              )}
            </div>
          )}

          {isModelLoaded && (
            <div className="model-controls">
              <button
                type="button"
                onClick={() => void unloadModel()}
                disabled={modelLoading || loading}
              >
                Unload Model
              </button>
            </div>
          )}

          {messages.map((m) => (
            <div key={m.id} className={`message ${m.role}`}>
              {m.text || (loading && m.role === 'assistant' ? '...' : m.text)}
            </div>
          ))}

          {error && (
            <div className="message assistant">Error: {error}</div>
          )}

          <div ref={messagesEndRef} />
        </div>

        <div className="composer">
          <textarea
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              isModelLoaded
                ? 'Ask something...'
                : 'Load a GGUF model first...'
            }
            rows={1}
            disabled={loading || !isModelLoaded}
          />

          <button
            type="button"
            onClick={() => void sendMessage()}
            disabled={
              loading || modelLoading || !isModelLoaded || !message.trim()
            }
          >
            {loading ? 'Thinking...' : 'Send'}
          </button>

          {loading && (
            <button
              type="button"
              onClick={() => void cancelGeneration()}
            >
              Cancel
            </button>
          )}
        </div>
      </div>
    </main>
  );
}

ReactDOM.createRoot(
  document.getElementById('root')!
).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
